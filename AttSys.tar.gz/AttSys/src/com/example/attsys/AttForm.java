package com.example.attsys;

import java.util.Calendar;




import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

public class AttForm extends Activity {
	
	String pob;
	int imc_met;
	private EditText etDate;
	private Spinner spin1;
	private Spinner spin2;
	private Spinner spin3;
	private ImageButton change_date;
	final int Date_Dialog_ID=0;
	int cDay,cMonth,cYear; // this is the instances of the current date
	private Calendar cDate;
	int sDay,sMonth,sYear; // this is the instances of the entered date

	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attform);
		etDate=(EditText)findViewById(R.id.dateid);
		change_date=(ImageButton)findViewById(R.id.imageButton1);
		spin1 = (Spinner) findViewById(R.id.selectbranch);
		spin2 = (Spinner) findViewById(R.id.selectsemid);
		spin3 = (Spinner) findViewById(R.id.selectsubid);
		
		//getting current date
		cDate=Calendar.getInstance();
		cDay=cDate.get(Calendar.DAY_OF_MONTH);
		cMonth=cDate.get(Calendar.MONTH);
		cYear=cDate.get(Calendar.YEAR);
		//assigning the edittext with the current date in the beginning
		sDay=cDay;
		sMonth=cMonth;
		sYear=cYear;
		updateDateDisplay(sYear,sMonth,sDay);
		
		change_date.setOnClickListener(new OnClickListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//triggers the DatePickerDialog
				showDialog(Date_Dialog_ID);
			}
		});
		
		final ArrayAdapter<String> ce8 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_8_sub));
		
		final ArrayAdapter<String> ce7 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_7_sub));
		
		final ArrayAdapter<String> ce6 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_6_sub));
		
		final ArrayAdapter<String> ce5 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_5_sub));
		
		final ArrayAdapter<String> ce4 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_4_sub));
		
		final	ArrayAdapter<String> ce3 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_3_sub));
		
		final ArrayAdapter<String> ce2 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_2_sub));
		
		 final ArrayAdapter<String> ce1 = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.ce_1_sub));
		 

		 final ArrayAdapter<String> it8 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_8_sub));
			
			final ArrayAdapter<String> it7 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_7_sub));
			
			final ArrayAdapter<String> it6 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_6_sub));
			
			final ArrayAdapter<String> it5 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_5_sub));
			
			final	ArrayAdapter<String> it4 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_4_sub));
			
			final ArrayAdapter<String> it3 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_3_sub));
			
			final ArrayAdapter<String> it2 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_1_sub));
			
			final ArrayAdapter<String> it1 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.it_1_sub));
			
			final ArrayAdapter<String> ee8 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_8_sub));
			
			final ArrayAdapter<String> ee7 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_7_sub));
			
			final ArrayAdapter<String> ee6 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_6_sub));
			
			final ArrayAdapter<String> ee5 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_5_sub));
			
			final ArrayAdapter<String> ee4 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_4_sub));
			
			final	ArrayAdapter<String> ee3 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_3_sub));
			
			final 	ArrayAdapter<String> ee2 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_2_sub));
			
			final ArrayAdapter<String> ee1 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.ee_1_sub));
			
			final ArrayAdapter<String> c8 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_8_sub));
			
			final ArrayAdapter<String> c7 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_7_sub));
			
			final ArrayAdapter<String> c6 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_6_sub));
			
			final ArrayAdapter<String> c5 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_5_sub));
			
			final ArrayAdapter<String> c4 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_4_sub));
				
			final ArrayAdapter<String> c3 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_3_sub));
			
			final 	ArrayAdapter<String> c2 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_2_sub));
			
			final ArrayAdapter<String> c1 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.c_1_sub));
			
			final	ArrayAdapter<String> m8 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_8_sub));
			
			final 	ArrayAdapter<String> m7 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_7_sub));
			
			final 	ArrayAdapter<String> m6 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_6_sub));
			 
			
			
			final ArrayAdapter<String> m5 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_5_sub));
			
			
			final ArrayAdapter<String> m4 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_4_sub));
			
			
			final	ArrayAdapter<String> m3 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_3_sub));
			
			final	ArrayAdapter<String> m2 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_2_sub));
			
			final ArrayAdapter<String> m1 = new ArrayAdapter<String>(this,
		            android.R.layout.simple_spinner_item, getResources()
		           .getStringArray(R.array.m_1_sub));
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
	            android.R.layout.simple_spinner_item, getResources()
	           .getStringArray(R.array.branch));//setting the country_array to spinner
	           adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	           spin1.setAdapter(adapter);
	           spin1.setOnItemSelectedListener(new OnItemSelectedListener() {
			   @Override
			   public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				  pob= spin1.getSelectedItem().toString();
		
					}
		
					@Override
					public void onNothingSelected(AdapterView<?> arg0) {
						// TODO Auto-generated method stub
						
					}	});
		
		ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,
			     android.R.layout.simple_spinner_item, getResources()
			       .getStringArray(R.array.sem));//setting the country_array to spinner
			        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
					
					spin2.setAdapter(adapter2);  
			
					spin2.setOnItemSelectedListener(new OnItemSelectedListener() {
			
						@Override
						public void onItemSelected(AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							imc_met=spin2.getSelectedItemPosition();
			
			
				if(pob.equals("Computer Engineering") )
					{

					switch (imc_met) 
					{
					
					default:
					break;
					
					case 0:
						
						ce1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce1);
						spin3.getAdapter();
						break;

					case 1:
						ce2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce2);
						spin3.getAdapter();
						break;

					
					case 2:
						ce3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce3);
						spin3.getAdapter();

						break;
					case 3:
						ce4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce4);
						spin3.getAdapter();

						break;
					case 4:
						ce5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce5);
						spin3.getAdapter();


						break;
					case 5:
						ce6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce6);
						spin3.getAdapter();


						break;
					case 6:
						ce7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce7);
						spin3.getAdapter();


						break;
					case 7:
						ce8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ce8);
						spin3.getAdapter();


						break;

					}
				}



				if(pob.equals("Information Technology") )
				{

					switch (imc_met) 
					{
					case 0:
						it1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it1);
						spin3.getAdapter();


						break;

					case 1:
						it2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it2);
						spin3.getAdapter();

						break;
					case 2:
						it3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it3);
						spin3.getAdapter();

						break;
					case 3:
						it4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it4);
						spin3.getAdapter();

						break;
					case 4:
						it5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it5);
						spin3.getAdapter();

						break;
					case 5:
						it6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it6);
						spin3.getAdapter();

						break;
					case 6:
						it7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it7);
						spin3.getAdapter();

						break;
					case 7:
						it8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(it8);
						spin3.getAdapter();

						break;

					default:
					
						break;
					}


				}

				if(pob.equals("Electronics and Electrical Engineering") )
				{

					switch (imc_met) 
					{
					case 0:
						ee1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee1);
						spin3.getAdapter();


						break;

					case 1:
						ee2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee2);
						spin3.getAdapter();

						break;
					case 2:
						ee3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee3);
						spin3.getAdapter();

						break;
					case 3:
						ee4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee4);
						spin3.getAdapter();

						break;
					case 4:
						ee5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee5);
						spin3.getAdapter();

						break;
					case 5:
						ee6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee6);
						spin3.getAdapter();

						break;
					case 6:
						ee7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee7);
						spin3.getAdapter();

						break;
					case 7:
						ee8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(ee8);
						spin3.getAdapter();

						break;

					default:
					
						break;
					}
				}

				if(pob.equals("Civil Engineering") )
				{

					switch (imc_met) 
					{
					case 0:
						c1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c1);
						spin3.getAdapter();

						break;

					case 1:
						c2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c2);
						spin3.getAdapter();

						break;
					case 2:
						c3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c3);
						spin3.getAdapter();

						break;
					case 3:
						c4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c4);
						spin3.getAdapter();

						break;
					case 4:
						c5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c5);
						spin3.getAdapter();

						break;
					case 5:
						c6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c6);
						spin3.getAdapter();

						break;
					case 6:
						c7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c7);
						spin3.getAdapter();

						break;
					case 7:
						c8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(c8);
						spin3.getAdapter();

						break;

					default:
					
						break;
					}
				}

				if(pob.equals("Mechanical Engineering") )
				{

					switch (imc_met) 
					{
					case 0:
						m1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m1);
						spin3.getAdapter();

						break;

					case 1:
						m2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m2);
						spin3.getAdapter();

						break;
					case 2:
						m3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m3);
						spin3.getAdapter();

						break;
					case 3:
						m4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m4);
						spin3.getAdapter();

						break;
					case 4:
						m5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m5);
						spin3.getAdapter();

						break;
					case 5:
						m6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m6);
						spin3.getAdapter();

						break;
					case 6:
						
						m7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
						spin3.setAdapter(m7);
						spin3.getAdapter();

						break;
					case 7:
						m8.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
						spin3.setAdapter(m8);
						spin3.getAdapter();

						break;

					default:
						
						break;
					}
				}

		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub

		}
	});

		
	}
	
	 public void backmethod(View v)
	    {
	    	startActivity(new Intent(this, HomeActivity.class));
	    }
	 
	 @SuppressWarnings("deprecation")
		public void infomethod(View v){
	    	AlertDialog alertDialog = new AlertDialog.Builder(this).create();
	    	alertDialog.setTitle("Sorry");
	    	alertDialog.setMessage("Temporary Data Connection Stop");
	    	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
	    	   public void onClick(DialogInterface dialog, int which) {
	    	      // TODO Add your code for the button here.
	    	   }
	    	});
	    	// Set the Icon for the Dialog
	    	alertDialog.setIcon(R.drawable.udimage);
	    	alertDialog.show();
	    }
	 
	
	protected Dialog onCreateDialog(int id) {
		 
		switch (id) {
		case Date_Dialog_ID:
		return new DatePickerDialog(this, onDateSet, cYear, cMonth,
		cDay);
		}
		return null;
	}
		 
	private void updateDateDisplay(int year,int month,int date) {
		// TODO Auto-generated method stub
		etDate.setText(date+"-"+(month+1)+"-"+year);
	}
	
	private OnDateSetListener onDateSet=new OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth){
			// TODO Auto-generated method stub
			System.out.println("2");
			sYear=year;
			sMonth=monthOfYear;
			sDay=dayOfMonth;
			updateDateDisplay(sYear,sMonth,sDay);
		}
	};
	
	public void ceeightmethod(View v){
		startActivity(new Intent(this, CeEight.class));
	}
	
}
