package com.example.attsys;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CeEight extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ce8);
         }
    
    public void backmethod(View v)
    {
    	startActivity(new Intent(this, AttForm.class));
    }
    
    @SuppressWarnings("deprecation")
	public void infomethod(View v){
    	AlertDialog alertDialog = new AlertDialog.Builder(this).create();
    	alertDialog.setTitle("Sorry");
    	alertDialog.setMessage("Temporary Data Connection Stop");
    	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
    	   public void onClick(DialogInterface dialog, int which) {
    	      // TODO Add your code for the button here.
    	   }
    	});
    	// Set the Icon for the Dialog
    	alertDialog.setIcon(R.drawable.udimage);
    	alertDialog.show();
    }
    
    @SuppressWarnings("deprecation")
	public void submitsuccess(View v){
    	AlertDialog alertDialog1 = new AlertDialog.Builder(this).create();
    	alertDialog1.setTitle("Report");
    	alertDialog1.setMessage("Attendance Submited successfuly");
    	alertDialog1.setButton("OK", new DialogInterface.OnClickListener() {
     	   public void onClick(DialogInterface dialog, int which) {
     	      // TODO Add your code for the button here.
     	   }
     	});
    	alertDialog1.show();
    	
    }
}